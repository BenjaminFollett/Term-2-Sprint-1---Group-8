
// Function to initialize the website
function init() {
    populateMenu();
    const orderForm = document.getElementById("order-form");
    orderForm.addEventListener("submit", submitOrder);
}

// Initialize the website when the DOM content is loaded
document.addEventListener("DOMContentLoaded", init);


document.getElementById("paragraph").style.lineHeight = "1"; 



document.addEventListener("DOMContentLoaded", function() {
    var home = document.getElementById("home");
    var detailBox = document.querySelector(".detailbox");
    
    
    setTimeout(function() {
      detailBox.style.opacity = "2";
    }, 100); d
      
  });

